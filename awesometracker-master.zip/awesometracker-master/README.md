# Awesome Time Tracker

This is a simple time tracker built with
* Java FX for UI
* JPA and an H2 database for data storage
* DynamicReports for building PDF reports.

**Prepackaged releases are available on [Github](/../../releases).**

I created the project after being frustrated with most free and open-source time tracking tools.

Project is still under development and some nice (planned) features are not yet ready.

Requires Java 8 to build and run.
