/**
 * @author Victor I. Afolabi
 *
 * A.I. Engineer & Software developer
 * javafolabi@gmail.com
 *
 * Created on 02 February, 2018 @ 1:19 AM.
 * Copyright © 2018. Victor. All rights reserved.
 */

import React from 'react';

import App from './containers/App';


export default <App/>;
